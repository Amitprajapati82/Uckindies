<?php $__env->startSection('content'); ?>

         <!--success / error-->
        <?php if(Session::get('success')): ?>
            <?php $message = Session::get('success') ?>
            <?php echo '<script>swal.fire({text:"'. $message .'",icon:"success",timer:3000,showConfirmButton:false});</script>' ?>
        <?php endif; ?>
        
        <?php if(Session::get('error')): ?>
            <?php $message = Session::get('error') ?>
            <?php echo '<script>swal.fire({text:"'. $message .'",icon:"error",timer:3000,showConfirmButton:false});</script>' ?>
        <?php endif; ?>
        
        
        <!-- Page Header End -->
        <div class="container py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Franchise</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
                        <!--li class="breadcrumb-item"><a href="#">Pages</a></li-->
                        <li class="breadcrumb-item text-white active" aria-current="page">Franchise</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->


        <div class="container py-5">
            <div class="container">
                <div class="row g-5 d-flex align-items-center justify-content-center">
                    <div class="col-lg-8 wow fadeInUp" data-wow-delay="0.1s">
                        <h1 class="mb-4">Franchise</h1>
                        <h4>Together, Let’s Prosper! </h4>
                        <h4 style="color:#FE5D37;">Setup Your Own Pre-School; Create a New Benchmark of Growth and Success </h4>
                        <p>Education is a sunrise sector in India. It is an expanding landscape that offers growth opportunities to entrepreneurs who aspire to break new ground.</p>
                        <p>UC Kindies is a brand that is cutting through the clutter in the competitive pre-school space. Our unique and robust learning model is indeed a growth lever that also brings appreciable commercial success.</p>
                        <p>If you are inspired about making radical new changes to the pre-schooling segment, team up with us as our Franchisee. It would be a long-lasting collaboration where your passion and dedication will be rewarded with progress and prosperity.</p>
                        <p>&nbsp;</p>
                        <h4 style="color:#FE5D37;">What We Look for in Our Franchises:</h4>
                          <ul>
                           <li><strong>Love</strong> for toddlers and kids</li>
                           <li><strong>Passion</strong> to be a successful and respectable  entrepreneur</li>
                           <li><strong>Space</strong> in a decent locality admeasuring 1,500 to 2,500 SQF</li>
                           <li><strong>Financial capability</strong> to invest 15 to 18 lac rupees as Project Cost</li>
                           <li><strong>Patience</strong> to wait for two years until breakeven point</li>
                          </ul>
                          <p>&nbsp;</p>
                          <h4 style="color:#FE5D37;">Franchising Key Highlights</h4>
                            <h3>Globally Acknowledged Brand</h3>
                            <p>With presence in 51 countries across 5 continents and over 5,000 franchises, you will benefit from a rewarding and long-lasting association with UC Kindies.</p>
                            <p>&nbsp;</p>
                            <h3>Superior Curriculum</h3>
                            <p>Our thoughtfully designed curriculum is based on 25 years of groundbreaking research in whole brain development.</p>
                            <p>&nbsp;</p>
                            <h3>Excellent Returns</h3>
                            <p>Our robust business model ensures you gain an appreciably high ROI.</p>
                            <p>&nbsp;</p>
                            <h3>Additional Revenue Streams</h3>
                            <p>You can augment your earnings through classes, camps, and many other activities.</p>
                            <p>&nbsp;</p>
                            <h3>End-to-end Support</h3>
                            <p>From orientation & staff training to advertising and admissions, we support our Franchises in every aspect.</p>

                        <p id="FranchiseForm">To register, kindly fill up the Form below:</p>
                    </div>
                </div>
            </div>
        </div>

        <!--Franchise Form Start here-->
        <form action="<?php echo e(route('home.franchiseform_submit')); ?>" method = "post" >
                                    <?php echo csrf_field(); ?>
            <div  class="col-8 container" style="background-color: #FFF5F3; border: 1px solid rgba(0,0,0,0.125); padding:30px; border-radius: 10px;">
              <div class="form-row">
                <div class="form-group col-md-6 mb-2">
                  <label for="inputEmail4">Email</label>
                  <input type="email" class="form-control" id="inputEmail4" placeholder="Email" name="email" required>
                </div>
                <!--<div class="form-group col-md-6">-->
                <!--  <label for="inputPassword4">Password</label>-->
                <!--  <input type="password" class="form-control" id="inputPassword4" placeholder="Password">-->
                <!--</div>-->
              </div>
              <div class="form-group mb-2">
                <label for="inputAddress">Address</label>
                <textarea class="form-control" id="inputAddress" name="address1" required></textarea>
              </div>
              <div class="form-group mb-2">
                <label for="inputAddress2">Address 2</label>
                <textarea class="form-control" id="inputAddress2" name="address2" required></textarea>
              </div>
              <div class="form-row">
                 <div class="form-group col-md-6 mb-2">
                  <label for="inputState">State</label>
                  <select id="inputState" class="form-control" name="state" required>
                    <option selected>Select State</option>
                    <option>Maharashtra</option>
                    <option>Rajasthan</option>
                    <option>Uttar Pradesh</option>
                  </select>
                </div>
                <div class="form-group col-md-6 mb-2">
                  <label for="inputCity">City</label>
                  <input type="text" class="form-control" id="inputCity" name="city" required>
                </div>
                
                <div class="form-group col-md-2 mb-2">
                  <label for="inputZip">Zip</label>
                  <input type="number" class="form-control" id="inputZip" name="zip" required>
                </div>
              </div>
              <div class="form-group mb-2" >
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="gridCheck" name="check" value="1">
                  <label class="form-check-label" for="gridCheck">
                    Check me out
                  </label>
                </div>
              </div>
              <button type="submit" class="btn btn-primary">Sign in</button>
             </div>
        </form>        
      <!--Franchise Form end here-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ideatore/public_html/2gether.co.in/uckindies_demo/resources/views/franchise.blade.php ENDPATH**/ ?>