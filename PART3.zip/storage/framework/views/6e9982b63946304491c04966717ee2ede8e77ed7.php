
<?php $__env->startSection('content'); ?>

        <!-- Page Header End -->
        <div class="container py-5 page-header3 position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Learning Centers</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Pages</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Centers</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->


        <div class="container py-5">
            <div class="container">
                <div class="row g-5 d-flex align-items-center justify-content-start">
                    
                    <?php if($data): ?>
                    
                     <?php $__currentLoopData = $State; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Statevalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php 
                     $key = 1; 
                     $url1 = strtolower($Statevalue->state_name);
                     $url = str_replace(' ', '_', $url1)
                     
                     ?>
                     
                    <h1 ><a href="<?php echo e(asset('states/'.$url)); ?>">	<?php echo e($Statevalue->state_name); ?> </a></h1>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <?php if($Statevalue->ID == $value->state_id): ?>
                        <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                            
                            <h4><?php echo e($key); ?>) <?php echo e($value->center); ?>  </h4>
                            <p><span>Address : - </span><span><?php echo e($value->address); ?></span></p>
                            <p><span>Contact No : - </span><span><?php echo e($value->contact); ?> </span></p>
                            <p><span>Email Id : - </span><span><?php echo e($value->email); ?></span></p>
                             <!--<p><span>Facebook Link : - </span><span>http://www.facebook.com/profile.php?id=100077292031184</span></p>-->
                             <!--<p><span>Insta Link : - </span><span></span></p>-->
                        </div>
                        <?php $key++; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                    
                </div>
            </div>
        </div>
        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/wtwvirmy/public_html/uckindiesindia/resources/views/centers.blade.php ENDPATH**/ ?>