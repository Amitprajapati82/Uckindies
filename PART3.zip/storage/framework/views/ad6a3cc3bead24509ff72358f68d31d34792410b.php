<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ideatore/public_html/2gether.co.in/uckindies_demo/resources/views/join_us.blade.php ENDPATH**/ ?>