
<?php $__env->startSection('content'); ?>


<style>

/* .card.tabcard.printtabrespon .card-body {*/
/*    padding: 0;*/
/*}*/

/*  .card.tabcard.printtabrespon .card-body img {*/
/*    width: 100%;*/
/*}*/
/*    .card.tabcard.printtabrespon {*/
    /*border: 10px solid red;*/
/*    margin-bottom: 20px;*/
/*    border-style: solid;*/
/*    border-width: 7px;*/
/*    border-image: conic-gradient (#ffdd00, #ffdd00, #e86d1f, #83401d, #00853f, #ffdd00) 1;*/
/*}*/
/*h2.mb-4.H1::after {*/
/*    content: '';*/
/*    display: block;*/
/*    height: 2px;*/
/*    width: 45%;*/
/*    background: red;*/
/*    margin-top: 5px;*/
/*    font-weight:400px;*/
/*}*/
</style>
        <!-- Page Header End -->
        <div class="container py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Awards</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
                        <!--<li class="breadcrumb-item"><a href="#">Pages</a></li>-->
                        <li class="breadcrumb-item text-white active" aria-current="page">Awards</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->
        
        
        
        <div class="row row-cols-1 row-cols-md-2 g-4">
  <div class="col">
    <div class="card">
      <img src="<?php echo e(asset('assets/img/Award  (2).jpg')); ?>" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title"> "HALL OF FAME AWARD" 2019 </h5>
        <p class="card-text"> "Top 50 Franchised Preschool in Asia" Awarded at city palace, jaipur 2019.</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="<?php echo e(asset('assets/img/award2a.jpg')); ?>" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="<?php echo e(asset('assets/img/Award 1.jpg')); ?>" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Internaional School Award </h5>
        <p class="card-text"> "Teaching Exellence" at Amity University Dubai,2020.</p>
             <h5><span>Chief Diector: <span>Dr.Deepak Vohra (Indian diplomat)</span></span></h5>
                      
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
      </div>
    </div>
  </div>
</div>




         
                 
            <!--<div class="container py-5">-->
            <!--<div class="container">-->
            <!--    <div class="col-md-6 mt-2 " data-src="<?php echo e(asset('assets/img/hall.jpg')); ?>">-->
            <!--            <div class="card tabcard printtabrespon" >-->
            <!--                <div class="card-body d-flex align-items-center justify-content-center " >-->
            <!--                     <img src="<?php echo e(asset('assets/img/hall.jpg')); ?>" class="img-fluid" alt="image small">-->
            <!--                </div>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    <div class="row g-5 d-flex align-items-center justify-content-center">-->
            <!--        <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">-->
            <!--            <h1 class="mb-4">  "HALL OF FAME AWARD" 2019 </h1>-->
            <!--            <h5> "Top 50 Franchised Preschool in Asia" Awarded at city palace, jaipur 2019</h5>-->
            <!--             </div>-->
                      
                    <!--      <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">-->
                    <!--           <div class="col-md-3 mt-2 " data-src="<?php echo e(asset('assets/img/galary1.jpg')); ?>">-->
                    <!--    <div class="card tabcard printtabrespon" >-->
                    <!--        <div class="card-body " >-->
                    <!--             <img src="<?php echo e(asset('assets/img/galary1.jpg')); ?>" class="img-fluid" alt="image small">-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--      <h1 class="mb-4">Dr.Arunabh Singh, Director </h1>-->
                    <!--     <h5>Nehru Worldschool Gaziabad and Smt.Asha Varma, senior Educationist   </h5>-->
                     
 
                    <!--</div>-->
            <!--        </div>-->
            <!--        </div>-->
            <!--        </div>-->
                    
                    
            <!-- <div class="container py-5">-->
            <!--<div class="container">-->
            <!--    <div class="col-md-3 mt-2 " data-src="<?php echo e(asset('assets/img/galary1.jpg')); ?>">-->
            <!--            <div class="card tabcard printtabrespon" >-->
            <!--                <div class="card-body " >-->
            <!--                     <img src="<?php echo e(asset('assets/img/Award  (2).jpg')); ?>" class="img-fluid" alt="image small">-->
            <!--                </div>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    <div class="row g-5 d-flex align-items-center justify-content-start">-->
            <!--        <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">-->
            <!--            <h1 class="mb-4">Dr.Arunabh Singh, Director</h1>-->
            <!--            <h5>Nehru Worldschool Gaziabad and Smt.Asha Varma, senior Educationist </h5>-->
                        <!--<h5><span>Chief Diector: <span>Dr.Deepak Vohra (Indian diplomat)</span></span></h5>-->
                      
            <!--             </div>-->
                    <!--      <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">-->
                              
                
                    <!--     <h5>UC Kindies Director Sanjay Bhoir Receiving Award from Dr.Deepak Vohra</h5>-->
                     
 
                    <!--</div>-->
            <!--        </div>-->
            <!--        </div>-->
            <!--        </div>-->
                    
            <!--           <div class="container py-5">-->
            <!--<div class="container">-->
            <!--    <div class="col-md-3 mt-2 " data-src="<?php echo e(asset('assets/img/galary1.jpg')); ?>">-->
            <!--            <div class="card tabcard printtabrespon" >-->
            <!--                <div class="card-body " >-->
            <!--                     <img src="<?php echo e(asset('assets/img/galary1.jpg')); ?>" class="img-fluid" alt="image small">-->
            <!--                </div>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    <div class="row g-5 d-flex align-items-center justify-content-start">-->
            <!--        <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">-->
            <!--            <h1 class="mb-4">Blue Certificate</h1>-->
            <!--            <h5>Internaional School Award "Teaching Exellence" at Amity University Dubai,2020</h5>-->
            <!--            <h5><span>Chief Diector: <span>Dr.Deepak Vohra (Indian diplomat)</span></span></h5>-->
                      
            <!--             </div>-->
            <!--             </div>-->
            <!--               </div>-->
            <!--        </div>-->
                    
            <!--<div class="container py-5">-->
            <!--<div class="container">-->
            <!--    <div class="col-md-3 mt-2 " data-src="<?php echo e(asset('assets/img/galary1.jpg')); ?>">-->
            <!--            <div class="card tabcard printtabrespon" >-->
            <!--                <div class="card-body " >-->
            <!--                     <img src="<?php echo e(asset('assets/img/galary1.jpg')); ?>" class="img-fluid" alt="image small">-->
            <!--                </div>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    <div class="row g-5 d-flex align-items-center justify-content-start">-->
            <!--        <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">-->
                        <!--<h1 class="mb-4">Blue Certificate</h1>-->
            <!--            <h5> UC Kindies Director Sanjay Bhoir Receiving Award from Dr.Deepak Vohra</h5>-->
                       
                      
            <!--             </div>-->
            <!--             </div>-->
            <!--               </div>-->
            <!--        </div>-->
                        
        
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/wtwvirmy/public_html/uckindiesindia/resources/views/awards.blade.php ENDPATH**/ ?>