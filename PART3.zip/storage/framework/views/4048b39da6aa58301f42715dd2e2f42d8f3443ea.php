
<?php $__env->startSection('content'); ?>

  <?php if(Session::get('success')): ?>
        <?php $message = Session::get('success') ?>
        <?php echo '<script>swal.fire({text:"'. $message .'",icon:"success",timer:3000,showConfirmButton:false});</script>' ?>
    <?php endif; ?>
    
      <?php if(Session::get('error')): ?>
        <?php $message = Session::get('error') ?>
        <?php echo '<script>swal.fire({text:"'. $message .'",icon:"error",timer:3000,showConfirmButton:false});</script>' ?>
    <?php endif; ?>
    
    <!--Main Area-->
    <div class="main-panel">
		<div class="content">
			<div class="page-inner">
				<div>
					<h4 class="page-title" style="text-align:center">Welcome</h4>
				</div>
				<div class="page-category">Admin</div>
			</div>
		</div>

	</div>
    <!--Main Area End-->

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/wtwvirmy/public_html/uckindiesindia/resources/views/admin/index.blade.php ENDPATH**/ ?>