@extends('layout')
@section('content')

@if(Session::has('Developer') || Session::has('Admin') )
    @php
        $url = asset('admin/dashboard');
        header('Location:'.$url);
        exit;
    @endphp

@endif

  <style>
.card.w-50{
    bottom:70px;
}

    
  </style>


               <!-- Page Header End -->
        <div class="container py-5  position-relative mb-5">
            <!--<div class="container py-5">-->
            <!--    <h1 class="display-2 text-white animated slideInDown mb-4">Programs</h1>-->
            <!--    <nav aria-label="breadcrumb animated slideInDown">-->
            <!--        <ol class="breadcrumb">-->
                        <!--<li class="breadcrumb-item"><a href="{{route('home.index')}}">Home</a></li>-->
                        <!--li class="breadcrumb-item"><a href="#">Pages</a></li-->
            <!--            <li class="breadcrumb-item text-white active" aria-current="page">Programs</li>-->
            <!--        </ol>-->
            <!--    </nav>-->
            <!--</div>-->
        </div>
        <!-- Page Header End -->   
        
        
        
        
        <div class="card w-50 mx-auto">
         <h5 class="card-header">Login</h5>
           <div class="card-body">
             <form action="{{asset('submit_login')}}" method="post">
                 @csrf
                 <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email"  placeholder="Enter Email " required>
                 </div>
                 <div class="mb-3">
                   <label for="password" class="form-label">Password</label>
                   <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password">
                 </div>
                 <div class="mb-3 d-flex justify-content-end">
                    <span class="psw"> <a href="forgot_password">Forgot Password?</a></span>
                 </div>
                     <button type="submit" class="btn btn-primary rounded-pill">Submit</button>
             </form>
           </div>
        </div>



@stop